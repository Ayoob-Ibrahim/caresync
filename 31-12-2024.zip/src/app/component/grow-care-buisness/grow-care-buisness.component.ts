import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-grow-care-buisness',
  imports: [CommonModule],
  templateUrl: './grow-care-buisness.component.html',
  styleUrl: './grow-care-buisness.component.scss'
})
export class GrowCareBuisnessComponent {

}
