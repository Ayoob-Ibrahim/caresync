import { Component } from '@angular/core';

@Component({
  selector: 'app-full-image-with-card-bottom',
  imports: [],
  templateUrl: './full-image-with-card-bottom.component.html',
  styleUrl: './full-image-with-card-bottom.component.scss'
})
export class FullImageWithCardBottomComponent {

}
