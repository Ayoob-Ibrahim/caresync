import { Component } from '@angular/core';

@Component({
  selector: 'app-full-img-card-on-bottom',
  imports: [],
  templateUrl: './full-img-card-on-bottom.component.html',
  styleUrl: './full-img-card-on-bottom.component.scss'
})
export class FullImgCardOnBottomComponent {

}
