import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-getstartedcard',
  imports: [CommonModule],
  templateUrl: './getstartedcard.component.html',
  styleUrl: './getstartedcard.component.scss'
})
export class GetstartedcardComponent {
@Input() data;
}
