import { CommonModule } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { GetstartedcardComponent } from '../getstartedcard/getstartedcard.component';
import VanillaTilt from 'vanilla-tilt';

@Component({
  selector: 'app-imageselecterpart',
  imports: [CommonModule,GetstartedcardComponent],
  templateUrl: './imageselecterpart.component.html',
  styleUrl: './imageselecterpart.component.scss'
})
export class ImageselecterpartComponent {
  @ViewChild('tiltElement') tiltElement!: ElementRef;
getstartedData=[
  {title:"Kickstart Your Ideal Care Business with Confidence ",content:"Make use of our expert guidance, personalised assistance and thorough training to bring your vision of a care business to fruition.",button:"Get Started"},
  {title:"Integrated Support for Startups in Health and Social Care",content:"Collaborate with us for encompassing solutions that ensure the success of your care agency from the beginning.",button:"Discover"},
  {title:"Arm Your Business with Essential Tools and Expert Knowledge ",content:"Gain access to a set of resources tailored to establish long term success for your care business.",button:"Dive Into Solutions"}
]
ngAfterViewInit() {
  VanillaTilt.init(this.tiltElement.nativeElement, {
    max: 25,
    speed: 400,
  });
}
}
